simple zip archive dictionary attack written in batch
